Ini paket INJECKTOR GACOR (final).
- index.html: halaman web (frontend).
- logo.png: logo (jika ada).
- qris.png: gambar QRIS (jika ada).

Cara pakai:
1. Ekstrak paket.
2. Buka index.html di browser lokal.
